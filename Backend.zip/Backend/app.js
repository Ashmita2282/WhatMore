import express from "express";
import { connect } from "./config/db.js";
import authRoutes from "./routes/authRoutes.js";

import cors from "cors";
const app = express();

import dotenv from "dotenv";

dotenv.config();

// Enable CORS
app.use(cors());

app.use(express.json());

// Route for authentication
app.use("/api", authRoutes);

connect();

export { app };
